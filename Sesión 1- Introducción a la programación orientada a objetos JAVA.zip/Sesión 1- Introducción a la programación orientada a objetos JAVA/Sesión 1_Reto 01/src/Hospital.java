public class Hospital {
    Package hospital;

    public static void main(String[] args) {

    }
}

