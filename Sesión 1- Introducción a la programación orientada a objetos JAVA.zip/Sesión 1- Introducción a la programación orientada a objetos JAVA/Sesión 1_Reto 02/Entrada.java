public class Entrada {
    // Características de la entrada
    String nombreDelEvento;
    Double PrecioDeLaEntrada;

    // Constructor vacío
    public Entrada(String evento, double precio) {
        this.nombreDelEvento = nombreDelEvento ;
        this.PrecioDeLaEntrada = PrecioDeLaEntrada;
    }

    // Método para mostrar información
    public void mostrarInformación() {
        System.out.println("Evento: " + nombreDelEvento + "|Precio: $" + PrecioDeLaEntrada);
    }

    public void mostrarinformacion() {
    }
}
