public class Principal {
    public static void main(String[] args) {
        String nombreDelEvento = null;
        Entrada entrada1 = new Entrada(nombreDelEvento: Object PrecioDeLaEntrada = null;
        String $3801 = "$3800";
        String $3800 = $3801;
        "Dua Lipa en concierto", PrecioDeLaEntrada;:);
        Entrada entrada2 =  new Entrada(nombreDelEvento: "Los Bandalos chinos en concierto", PrecioDeLaEntrada: "$800);
        
        entrada1.mostrarinformacion();
        entrada1.mostrarinformacion();
        
        
        
    }
}
